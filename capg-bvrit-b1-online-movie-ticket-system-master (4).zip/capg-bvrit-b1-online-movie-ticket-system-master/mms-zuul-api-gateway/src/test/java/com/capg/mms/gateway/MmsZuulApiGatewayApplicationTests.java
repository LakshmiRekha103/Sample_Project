package com.capg.mms.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmsZuulApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
