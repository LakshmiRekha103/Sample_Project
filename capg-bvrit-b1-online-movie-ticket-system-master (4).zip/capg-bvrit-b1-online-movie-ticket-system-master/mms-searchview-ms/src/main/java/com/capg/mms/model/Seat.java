package com.capg.mms.model;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

public class Seat {
//private int seatId;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="seatId")
	@JsonBackReference
	private Show show;
public Show getShow() {
		return show;
	}
	public void setShow(Show show) {
		this.show = show;
	}
private Enum seatStatus;
private double seatPrice;

	/*
	 * public int getSeatId() { return seatId; } public void setSeatId(int seatId) {
	 * this.seatId = seatId; }
	 */public Enum getSeatStatus() {
	return seatStatus;
}
public void setSeatStatus(Enum seatStatus) {
	this.seatStatus = seatStatus;
}
public double getSeatPrice() {
	return seatPrice;
}
public void setSeatPrice(double seatPrice) {
	this.seatPrice = seatPrice;
}
@Override
public String toString() {
	return "Seat [seatId=" + ", seatStatus=" + seatStatus + ", seatPrice=" + seatPrice + "]";
}

}
