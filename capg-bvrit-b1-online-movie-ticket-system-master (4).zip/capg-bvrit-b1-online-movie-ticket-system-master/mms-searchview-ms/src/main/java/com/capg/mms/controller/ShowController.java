package com.capg.mms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.capg.mms.model.Show;
import com.capg.mms.service.ShowServiceImpl;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/show")
public class ShowController {
	@Autowired
	ShowServiceImpl showService;
	
	
	@PostMapping("/add")
	public ResponseEntity<Show> addShow(@Valid@RequestBody Show show) {
		Show show1 = showService.addShow(show);
		ResponseEntity<Show> rt = new ResponseEntity<Show>(show1, HttpStatus.CREATED);
		return rt;
	}
	
	
	@GetMapping("/all")
	public ResponseEntity<List<Show>> findAllShows() throws Exception {

		List<Show> list = showService.findAllShows();
		ResponseEntity<List<Show>> rt = new ResponseEntity<List<Show>>(list, HttpStatus.OK);
		return rt;
	}
	
	@GetMapping("/search/{showId}")
	public ResponseEntity<Show> getShowById(@PathVariable int showId) throws Exception{
		Show show  =  showService.getShowById(showId);
		ResponseEntity<Show>  rt  =  new ResponseEntity<Show>(show,HttpStatus.OK);
		return rt;
	}
	@ExceptionHandler(Exception.class)
	public String inValid(Exception e) {
		return e.getMessage();
	}


}
