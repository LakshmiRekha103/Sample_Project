package com.capg.mms.service;

import java.util.List;

import com.capg.mms.model.Show;


public interface IShowService {
	Show addShow(Show show);
	List<Show> findAllShows() throws Exception;
	Show getByShowName(String showName);
	Show getShowById(int showId);
}
