package com.capg.mms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.mms.model.Movie;
//import com.capg.mms.service.IMovieService;
import com.capg.mms.service.MovieServiceImpl;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/movie")
public class MovieController {

	@Autowired
	MovieServiceImpl movieService;
	
//	....Movie operations
	
	@PostMapping("/add")
	public ResponseEntity<Movie> addMovie(@Valid@RequestBody Movie movie) {
		Movie movie1 = movieService.addMovie(movie);
		ResponseEntity<Movie> rt = new ResponseEntity<Movie>(movie1, HttpStatus.CREATED);
		return rt;
	}
	
	
	@GetMapping("/all")
	public ResponseEntity<List<Movie>> findAllMovies() throws Exception {

		List<Movie> list = movieService.findAllMovies();
		ResponseEntity<List<Movie>> rt = new ResponseEntity<List<Movie>>(list, HttpStatus.OK);
		return rt;
	}

	
//	@GetMapping("/search")
//	public ResponseEntity<Movie> getMovieByName() throws Exception{
//		
//		Movie findmovie  =  movieService.getMovieByName(movieName);
//		ResponseEntity<Movie> rt = new ResponseEntity<Movie>(findmovie,HttpStatus.OK);
//		return rt;	
//}
//	
////	
	@GetMapping("/search/{movieId}")
	public ResponseEntity<Movie> getMovieById(@PathVariable int movieId) throws Exception{
		Movie movie  =  movieService.getMovieById(movieId);
		ResponseEntity<Movie>  rt  =  new ResponseEntity<Movie>(movie,HttpStatus.OK);
		return rt;
	}
	@ExceptionHandler(Exception.class)
	public String inValid(Exception e) {
		return e.getMessage();
	}

}
