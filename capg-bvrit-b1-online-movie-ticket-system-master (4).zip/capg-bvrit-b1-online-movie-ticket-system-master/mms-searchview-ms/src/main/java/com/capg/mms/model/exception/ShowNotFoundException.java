package com.capg.mms.model.exception;

public class ShowNotFoundException extends RuntimeException {

	public ShowNotFoundException(String message) {
		super(message);

}
}
