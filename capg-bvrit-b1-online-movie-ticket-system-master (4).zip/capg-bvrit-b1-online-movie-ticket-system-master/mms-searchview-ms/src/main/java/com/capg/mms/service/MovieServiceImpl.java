package com.capg.mms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.mms.model.Movie;
import com.capg.mms.model.exception.MovieNotFoundException;
import com.capg.mms.repository.IMovieRepo;

@Service
public class MovieServiceImpl implements IMovieService{
	
	
@Autowired(required=true)
IMovieRepo movierepo;

@Override
@Transactional
public Movie addMovie(Movie movie) {
	System.out.println(movie);
	  return movierepo.save(movie);

}




@Override
public List<Movie> findAllMovies() throws Exception {
	return movierepo.findAll();
}



@Override
public Movie getMovieById(int movieId) {
	if (!movierepo.existsById(movieId)) {
			throw new MovieNotFoundException(" Movie not found");
		}
		return movierepo.findById(movieId).get();
	}




@Override
public Movie getByMovieName(String movieName) {
	return movierepo.getByMovieName(movieName);
}







}
