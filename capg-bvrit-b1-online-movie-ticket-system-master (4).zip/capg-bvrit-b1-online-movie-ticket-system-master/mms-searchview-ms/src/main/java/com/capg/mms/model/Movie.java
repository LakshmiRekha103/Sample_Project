package com.capg.mms.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
@Entity
@Table(name="movie")
public class Movie {
@Id
private int movieId;
@NotEmpty(message="MovieName is Mandatory field, Please provide MovieName")
private String movieName;
@OneToOne(mappedBy = "movie",cascade = CascadeType.ALL)
private List<Show> listOfShows;
@ElementCollection
private List<String> languages;
private String movieDirector;
private int movieLength;
public int getMovieId() {
	return movieId;
}
public void setMovieId(int movieId) {
	this.movieId = movieId;
}
public String getMovieName() {
	return movieName;
}
public void setMovieName(String movieName) {
	this.movieName = movieName;
}
public List<Show> getListOfShows() {
	return listOfShows;
}
public void setListOfShows(List<Show> listOfShows) {
	for (Show show : listOfShows) {
		show.setMovie(this);
	}
	this.listOfShows = listOfShows;
}
public List<String> getLanguages() {
	return languages;
}
public void setLanguages(List<String> languages) {
	this.languages = languages;
}
public String getMovieDirector() {
	return movieDirector;
}
public void setMovieDirector(String movieDirector) {
	this.movieDirector = movieDirector;
}
public int getMovieLength() {
	return movieLength;
}
public void setMovieLength(int movieLength) {
	this.movieLength = movieLength;
}
@Override
public String toString() {
	return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", listOfShows=" + listOfShows + ", languages="
			+ languages + ", movieDirector=" + movieDirector + ", movieLength=" + movieLength + "]";
}

}