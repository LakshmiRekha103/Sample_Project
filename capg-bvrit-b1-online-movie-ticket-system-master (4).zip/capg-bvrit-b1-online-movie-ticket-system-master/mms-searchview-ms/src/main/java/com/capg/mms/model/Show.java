package com.capg.mms.model;

import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="show")

public class Show {
@Id
private int showId;
public Movie getMovie() {
	return movie;
}
public void setMovie(Movie movie) {
	this.movie = movie;
}
@DateTimeFormat(pattern = "yyyy/MM/ddThh:mm:ss")
private LocalDateTime showStartTime;
@DateTimeFormat(pattern = "yyyy/MM/ddThh:mm:ss")
private LocalDateTime showEndTime;
@OneToOne(fetch = FetchType.LAZY)
@JoinColumn(name="movieId")
private Movie movie;
@OneToMany(mappedBy = "show",cascade = CascadeType.ALL)
private List<Seat> seats;
@NotEmpty(message="showName is Mandatory field, Please provide showName")
private String showName;
//private int movieId;
private int screenId;
private int theatreId;
public int getShowId() {
	return showId;
}
public void setShowId(int showId) {
	this.showId = showId;
}
public LocalDateTime getShowStartTime() {
	return showStartTime;
}
public void setShowStartTime(LocalDateTime showStartTime) {
	this.showStartTime = showStartTime;
}
public LocalDateTime getShowEndTime() {
	return showEndTime;
}
public void setShowEndTime(LocalDateTime showEndTime) {
	this.showEndTime = showEndTime;
}
public List<Seat> getSeats() {
	return seats;
}
public void setSeats(List<Seat> seats) {
	for (Seat seat : seats) {
		seat.setShow(this);
	}
	this.seats = seats;
}
public String getShowName() {
	return showName;
}
public void setShowName(String showName) {
	this.showName = showName;
}

	/*
	 * public int getMovieId() { return movieId; } public void setMovieId(int
	 * movieId) { this.movieId = movieId; }
	 */
public int getScreenId() {
	return screenId;
}
public void setScreenId(int screenId) {
	this.screenId = screenId;
}
public int getTheatreId() {
	return theatreId;
}
public void setTheatreId(int theatreId) {
	this.theatreId = theatreId;
}
@Override
public String toString() {
	return "Show [showId=" + showId + ", showStartTime=" + showStartTime + ", showEndTime=" + showEndTime + ", seats="
			+ seats + ", showName=" + showName + ", + screenId=" + screenId + ", theatreId="
			+ theatreId + "]";
}
}

