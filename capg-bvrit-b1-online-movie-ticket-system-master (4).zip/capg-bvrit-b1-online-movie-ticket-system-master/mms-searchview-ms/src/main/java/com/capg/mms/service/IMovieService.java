package com.capg.mms.service;

import java.util.List;

import com.capg.mms.model.Movie;

public interface IMovieService {
	
	
	Movie addMovie(Movie movie);
	List<Movie> findAllMovies() throws Exception;
	Movie getByMovieName(String movieName);
	Movie getMovieById(int movieId);
}
