package com.capg.mms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capg.mms.model.Show;
import com.capg.mms.model.exception.ShowNotFoundException;
import com.capg.mms.repository.IShowRepo;
@Service
public class ShowServiceImpl implements IShowService{
@Autowired
IShowRepo showrepo;

	@Override
	@Transactional
	public Show addShow(Show show) {
		// TODO Auto-generated method stub
		return showrepo.save(show);
	}

	@Override
	public List<Show> findAllShows() throws Exception {
		// TODO Auto-generated method stub
		return showrepo.findAll();

	}

	@Override
	public Show getShowById(int showId) {
		// TODO Auto-generated method stub
		if (!showrepo.existsById(showId)) {
			throw new ShowNotFoundException(" show not found");
		}
		return showrepo.findById(showId).get();
	}

	
	 @Override public Show getByShowName(String showName) { // TODO Auto-generated
	
		  return showrepo.getByShowName(showName); }
	 
	/*
	 * @Override public Show getShowById(int showId) { // TODO Auto-generated method
	 * stub return showrepo.getOne(showId); }
	 */

}
