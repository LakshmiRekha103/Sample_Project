package com.capg.mms.theatre.model;

public enum BookingState {

	AVAILABLE,BOOKED,BLOCKED;
}
