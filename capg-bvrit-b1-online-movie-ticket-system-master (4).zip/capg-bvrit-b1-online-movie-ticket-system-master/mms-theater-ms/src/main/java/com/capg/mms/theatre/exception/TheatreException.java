package com.capg.mms.theatre.exception;



public class TheatreException extends Exception {

	public TheatreException(String message)
	{
		super(message);
	
	}
	public TheatreException()
	{
		super();
	}
}
