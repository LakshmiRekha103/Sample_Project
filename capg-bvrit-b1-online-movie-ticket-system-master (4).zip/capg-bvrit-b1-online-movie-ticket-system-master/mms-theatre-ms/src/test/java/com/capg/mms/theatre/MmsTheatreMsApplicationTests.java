package com.capg.mms.theatre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmsTheatreMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
