package com.capg.mms.exceptions;

public class SeatAlreadyExistException extends RuntimeException {

	public SeatAlreadyExistException(String message) {

			super(message);

		}


}