package com.capg.mms.bookings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmsBookingMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
