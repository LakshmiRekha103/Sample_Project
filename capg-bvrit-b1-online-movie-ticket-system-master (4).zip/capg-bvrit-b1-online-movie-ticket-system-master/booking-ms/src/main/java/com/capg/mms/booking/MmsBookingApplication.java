package com.capg.mms.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MmsBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MmsBookingApplication.class, args);
	}

}
