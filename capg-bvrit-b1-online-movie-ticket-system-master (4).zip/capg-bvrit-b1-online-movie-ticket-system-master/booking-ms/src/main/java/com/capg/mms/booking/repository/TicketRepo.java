package com.capg.mms.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.mms.booking.model.Ticket;

public interface TicketRepo extends JpaRepository<Ticket, Integer> {

}
