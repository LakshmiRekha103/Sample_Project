package com.capg.mms.booking.Exception;

public class TicketCancellationException extends Exception{

	public TicketCancellationException(String message) {
		super(message);
	}
	
}
