package com.capg.mms.booking.model;

public enum BookingState {

	AVAILABLE,BOOKED,BLOCKED;
}
