package com.capg.mms.booking.Exception;

public class TicketNotFoundException extends Exception {
	
	public TicketNotFoundException(String message) {
		super(message);
	}

}
