package com.capg.mms.booking.Exception;

public class BookingBlockedException extends Exception{
	
	public BookingBlockedException(String message) {
		super(message);
	}

}
