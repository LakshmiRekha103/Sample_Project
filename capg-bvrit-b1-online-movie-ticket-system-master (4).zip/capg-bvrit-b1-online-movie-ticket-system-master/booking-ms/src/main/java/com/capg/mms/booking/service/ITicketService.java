package com.capg.mms.booking.service;

import com.capg.mms.booking.Exception.TicketCancellationException;
import com.capg.mms.booking.Exception.TicketNotFoundException;
import com.capg.mms.booking.model.Booking;
import com.capg.mms.booking.model.Ticket;

public interface ITicketService {
	
	public boolean cancelTicketById(int seatId) throws TicketCancellationException;
	public Ticket getTicketById(int ticketId) throws TicketNotFoundException;

}
