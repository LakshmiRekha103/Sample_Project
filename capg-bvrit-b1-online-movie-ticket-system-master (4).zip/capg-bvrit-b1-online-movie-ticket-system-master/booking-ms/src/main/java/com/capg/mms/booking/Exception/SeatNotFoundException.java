package com.capg.mms.booking.Exception;

public class SeatNotFoundException extends Exception{
	
	public SeatNotFoundException(String message) {
		super(message);
	}

}
