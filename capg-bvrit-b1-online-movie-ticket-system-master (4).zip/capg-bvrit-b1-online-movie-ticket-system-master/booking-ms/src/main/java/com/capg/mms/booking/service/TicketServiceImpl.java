package com.capg.mms.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.mms.booking.Exception.TicketCancellationException;
import com.capg.mms.booking.Exception.TicketNotFoundException;
import com.capg.mms.booking.model.Booking;
import com.capg.mms.booking.model.Ticket;

import com.capg.mms.booking.repository.TicketRepo;
@Service
public class TicketServiceImpl implements ITicketService {
	@Autowired(required = true)
    TicketRepo ticketRepo;

	@Override
	public Ticket getTicketById(int ticketId) {
		// TODO Auto-generated method stub
		return ticketRepo.getOne(ticketId);
	}

	@Override
	public boolean cancelTicketById(int seatId) throws TicketCancellationException {

		boolean flag = false;
		if (ticketRepo.existsById(seatId)) {
			// deleteTheatre = theatreRepo.findById(theatreId).get();
			ticketRepo.deleteById( seatId);
		} else {
			throw new TicketCancellationException("Cancellation Failed : Id not found");
		}
		return flag;

	}

}
