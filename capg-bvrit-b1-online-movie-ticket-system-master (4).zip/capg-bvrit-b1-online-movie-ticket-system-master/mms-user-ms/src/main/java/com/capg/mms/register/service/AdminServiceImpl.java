package com.capg.mms.register.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.capg.mms.register.model.Movie;
import com.capg.mms.register.model.Screen;
import com.capg.mms.register.model.ScreenList;
import com.capg.mms.register.model.Show;
import com.capg.mms.register.model.ShowList;
import com.capg.mms.register.model.Theatre;
import com.capg.mms.register.model.TheatreList;


@Service
public class AdminServiceImpl implements IAdminService {

	@Autowired
	RestTemplate rt;
	
//////////////////////////////////////////theatremethods//////////////////////////////////////////
	public Theatre addTheatre(Theatre theatre) {
		
		return rt.postForObject("http://theatre-ms/theatres/add", theatre, Theatre.class);
	}
	@Override
	public Theatre updateTheatre(int theatreId) {
		Theatre t= rt.postForObject("http://theatre-ms/theatres/add", theatreId, Theatre.class);
		 rt.put("http://theater-ms/theatres/update", t,t);
		 return t;
	}

	@Override
	public TheatreList findAllTheatres() {
		TheatreList theatreList=rt.getForObject("http://theatre-ms/theatres/all", TheatreList.class);
		return theatreList;
	}

	@Override
	public void deleTheatreById(int theatreId) {
		
		rt.delete("http://theatre-ms/theatres/delete/id/"+theatreId);
	}
	
	
//	//////////////////////////////////show methods//////////////////////////////////////////////////////
//	
//	public Show addShow(Show show) {
//		
//		return rt.postForObject("http://theatre-ms/theatres/show/add", show, Show.class);
//	}
//	
//	@Override
//	public void deleteShowById(int showId) {
//		
//		 rt.delete("http://theatre-ms/theatres/show/delete/id/"+showId);
//	}
//	
//	@Override
//	public Show updateShow(Show show) {
//		Show shows=rt.postForObject("http://theatre-ms/theatres/show/add", show, Show.class);
//		rt.put("http://theatre-ms/theatres/show/update", shows,shows);
//		return shows;
//	}
//
//	@Override
//	public ShowList findAllShows() {
//		ShowList showList=rt.getForObject("http://theatre-ms/theatres/show/all", ShowList.class);
//		return showList;
//	}
//	
//	///////////////////////////////////////////Screen methods/////////////////////////////////////////////////////
	
//	public Screen addScreen(Screen screen) {
//		
//		return rt.postForObject("http://theatre-ms/theatres/screen/add", screen, Screen.class);
//	}
//	@Override
//	public void deleteScreenById(int screenId) {
//		
//		 rt.delete("http://theatre-ms/theatres/screen/delete/id/"+screenId);
//	}
//
//	@Override
//	public Screen updateScreen(Screen screen) {
//	Screen s=rt.postForObject("http://theatre-ms/theatres/screen/add", screen, Screen.class);
//	rt.put("http://theatre-ms/theatres/screen/update",s,s);
//		return s;
//	}
//
//	@Override
//	public ScreenList findAllScreens() {
//		
//		ScreenList screenList= rt.getForObject("http://theatre-ms/theatres/screen/all", ScreenList.class);
//		return screenList;
//	}
//	
//	////////////////////////////////////////////Movie methods///////////////////////////////////////////////////////////
//	
//	
	@Override
	public Movie addMovie(Movie movie) {
		
		return rt.postForObject("http://movie-ms/movies/add", movie, Movie.class);
	}
	@Override
	public void deleteMovieById(int movieId) {
		
		rt.delete("http://movie-ms/movies/delete/id/"+movieId);
		
	}
	@Override
	public Movie updateMovie(Movie movie) {
		Movie m=rt.postForObject("http://movie-ms/movies/add", movie, Movie.class);
		rt.put("http://movie-ms/movies/update", m,m);
		return m;
	}
	@Override
	public Movie getMovieById(int movieId) {
		Movie movie=rt.getForObject("http://movie-ms/movies/get/id/"+movieId, Movie.class);
		
		return movie;
	}

	



	


}
