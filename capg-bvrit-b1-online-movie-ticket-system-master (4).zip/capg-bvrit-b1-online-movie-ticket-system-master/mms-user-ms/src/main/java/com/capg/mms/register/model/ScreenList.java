package com.capg.mms.register.model;

import java.util.List;

public class ScreenList {
	private List<Screen> screenList;
	public ScreenList() {
		// TODO Auto-generated constructor stub
	}
	public List<Screen> getScreenList() {
		return screenList;
	}
	public void setScreenList(List<Screen> screenList) {
		this.screenList = screenList;
	}
	public ScreenList(List<Screen> screenList) {
		super();
		this.screenList = screenList;
	}
	

}
