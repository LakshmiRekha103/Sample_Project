package com.capg.mms.register.model;

import java.util.List;

public class TheatreList {

	private List<Theatre> theatreList;
	public TheatreList() {
		// TODO Auto-generated constructor stub
	}
	public TheatreList(List<Theatre> theatreList) {
		super();
		this.theatreList = theatreList;
	}
	public List<Theatre> getTheatreList() {
		return theatreList;
	}
	public void setTheatreList(List<Theatre> theatreList) {
		this.theatreList = theatreList;
	}
}
