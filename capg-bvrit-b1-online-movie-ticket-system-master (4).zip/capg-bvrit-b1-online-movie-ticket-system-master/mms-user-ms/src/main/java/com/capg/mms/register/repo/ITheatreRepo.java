package com.capg.mms.register.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.mms.register.model.Theatre;

public interface ITheatreRepo extends JpaRepository<Theatre,Integer> {

}
