package com.capg.mms.register.service;



import com.capg.mms.register.model.Movie;
import com.capg.mms.register.model.Screen;
import com.capg.mms.register.model.ScreenList;
import com.capg.mms.register.model.Show;
import com.capg.mms.register.model.ShowList;
import com.capg.mms.register.model.Theatre;
import com.capg.mms.register.model.TheatreList;



public interface IAdminService {

	Theatre addTheatre (Theatre theatre);
	void deleTheatreById(int theatreId);
	Theatre updateTheatre(int theatreId);
	TheatreList findAllTheatres();
	
	
	
	Movie addMovie(Movie movie);
	void deleteMovieById(int movieId);
	Movie updateMovie(Movie movie);
	Movie getMovieById(int movieId);

//	Screen addScreen (Screen screen);
//	void deleteScreenById(int screenId);
//	Screen updateScreen(Screen screen);
//	ScreenList findAllScreens();
////	
//
//	Show addShow (Show show);	
//	Show updateShow(Show show);
//	ShowList findAllShows();
//	void deleteShowById(int showId);
//	
}
