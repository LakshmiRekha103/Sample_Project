package com.capg.mms.register.model;

import java.util.List;

public class ShowList {

	private List<Show> showList;
	public ShowList() {
		// TODO Auto-generated constructor stub
	}
	public ShowList(List<Show> showList) {
		super();
		this.showList = showList;
	}
	public List<Show> getShowList() {
		return showList;
	}
	public void setShowList(List<Show> showList) {
		this.showList = showList;
	}
	
}
