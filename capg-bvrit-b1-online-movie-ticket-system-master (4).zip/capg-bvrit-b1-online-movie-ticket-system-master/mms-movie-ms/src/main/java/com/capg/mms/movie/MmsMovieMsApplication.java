package com.capg.mms.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MmsMovieMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MmsMovieMsApplication.class, args);
	}

}
