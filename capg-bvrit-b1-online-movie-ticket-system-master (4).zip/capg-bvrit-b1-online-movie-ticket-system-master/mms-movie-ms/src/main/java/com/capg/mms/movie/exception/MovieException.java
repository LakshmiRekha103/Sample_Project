package com.capg.mms.movie.exception;

public class MovieException extends Exception {

	public MovieException(String message) {
		super(message);
	}
	 public MovieException(){
		// TODO Auto-generated constructor stub
	
		super();
	}

}
