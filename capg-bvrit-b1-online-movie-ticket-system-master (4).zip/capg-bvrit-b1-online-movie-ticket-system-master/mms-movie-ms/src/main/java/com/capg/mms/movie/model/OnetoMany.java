package com.capg.mms.movie.model;

public @interface OnetoMany {

}
