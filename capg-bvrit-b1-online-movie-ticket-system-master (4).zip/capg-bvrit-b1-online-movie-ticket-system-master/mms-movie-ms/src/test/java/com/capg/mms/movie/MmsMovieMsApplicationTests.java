package com.capg.mms.movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmsMovieMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
