package com.capg.mms.bookingmovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmsBookingMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
