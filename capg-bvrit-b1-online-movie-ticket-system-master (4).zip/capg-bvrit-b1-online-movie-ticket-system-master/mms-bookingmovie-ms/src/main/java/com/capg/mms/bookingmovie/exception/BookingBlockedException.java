package com.capg.mms.bookingmovie.exception;

public class BookingBlockedException extends Exception{
	
	public BookingBlockedException(String message) {
		super(message);
	}

}
