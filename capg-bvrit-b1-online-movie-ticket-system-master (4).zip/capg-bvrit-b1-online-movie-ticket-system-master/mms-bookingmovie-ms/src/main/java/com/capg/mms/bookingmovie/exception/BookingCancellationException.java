package com.capg.mms.bookingmovie.exception;

public class BookingCancellationException extends Exception{

	public BookingCancellationException(String message) {
		super(message);
	}
	
}
