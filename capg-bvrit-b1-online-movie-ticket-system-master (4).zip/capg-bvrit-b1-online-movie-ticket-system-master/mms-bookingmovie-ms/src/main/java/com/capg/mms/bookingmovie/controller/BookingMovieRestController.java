package com.capg.mms.bookingmovie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.mms.bookingmovie.exception.BookingBlockedException;
import com.capg.mms.bookingmovie.exception.BookingCancellationException;
import com.capg.mms.bookingmovie.model.BookingMovieBean;
import com.capg.mms.bookingmovie.model.BookingMovieList;
import com.capg.mms.bookingmovie.service.BookingMovieServiceImpl;



@RestController
@RequestMapping("/booking")
public class BookingMovieRestController {

	@Autowired
	BookingMovieServiceImpl service;

	@PostMapping("/addbooking")
	public ResponseEntity<BookingMovieBean> createBook(@RequestBody BookingMovieBean bean) {
		return new ResponseEntity<BookingMovieBean>(service.addBooking(bean),HttpStatus.CREATED);
	}
	
	@GetMapping("/all")
	public BookingMovieList viewAllBookings() {
		return service.getAllBookings();
	}
	
	@GetMapping("/{bookingid}")
	public BookingMovieBean getBookingById(@PathVariable int bookingid) {
		return service.getBookingById(bookingid);
	}
	
	@DeleteMapping("/{bookingId}")
	public void deleteBooking(@PathVariable int bookingId) throws BookingCancellationException{
		service.cancelBookingById(bookingId);
	}
}
