package com.capg.mms.bookingmovie.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capg.mms.bookingmovie.repository.BookingMovieRepo;
import com.capg.mms.bookingmovie.exception.BookingBlockedException;
import com.capg.mms.bookingmovie.exception.BookingCancellationException;
import com.capg.mms.bookingmovie.model.BookingMovieBean;
import com.capg.mms.bookingmovie.model.BookingMovieList;
import com.capg.mms.bookingmovie.repository.BookingMovieRepo;
//import com.capg.omts.entity.BookingMovieBean;

//@Repository
//@Transactional
@Service
public class BookingMovieServiceImpl implements IBookingMovieService{
	
	@Autowired(required = true)
    BookingMovieRepo bookingmovieRepo;
	
	@Override
	public BookingMovieBean addBooking(BookingMovieBean bean) {
		bookingmovieRepo.save(bean);
	    return bean;
	}

	@Override
	public BookingMovieList getAllBookings() {
		//TypedQuery<BookingMovieBean> query = bookingmovieRepo.createQuery("from BookingMovieBean", BookingMovieBean.class);
		return  new BookingMovieList(bookingmovieRepo.findAll());
	}

	
	@Override
	public BookingMovieBean getBookingById(int bookingid) {
		return bookingmovieRepo.getOne(bookingid);
	}
	
	@Override
	public int cancelBookingById(int bookingId) throws BookingCancellationException {
		//BookingMovieBean booking = bookingmovieRepo.find(BookingMovieBean.class, id);
		//bookingmovieRepo.remove(bookingId);
		//return bookingId;
		if (bookingmovieRepo.existsById(bookingId)) {
			bookingmovieRepo.deleteById( bookingId);
		} else {
			throw new BookingCancellationException("Cancellation Failed : Id not found");
		}
		return bookingId;
	}


}
