package com.capg.mms.bookingmovie.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.mms.bookingmovie.model.BookingMovieBean;

public interface BookingMovieRepo  extends JpaRepository<BookingMovieBean,Integer>{

}
