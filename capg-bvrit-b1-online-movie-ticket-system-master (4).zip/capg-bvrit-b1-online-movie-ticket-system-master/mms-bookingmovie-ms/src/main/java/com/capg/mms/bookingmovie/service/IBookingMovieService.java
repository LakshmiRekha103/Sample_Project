package com.capg.mms.bookingmovie.service;

import java.util.List;

import com.capg.mms.bookingmovie.exception.BookingBlockedException;
import com.capg.mms.bookingmovie.exception.BookingCancellationException;
import com.capg.mms.bookingmovie.model.BookingMovieBean;
import com.capg.mms.bookingmovie.model.BookingMovieList;


public interface IBookingMovieService {

	public BookingMovieBean addBooking(BookingMovieBean bean);

	public BookingMovieList getAllBookings();

	public BookingMovieBean getBookingById(int id);

	public int cancelBookingById(int bookingId) throws BookingCancellationException;
	
//	public List<Seat> chooseSeats(int seatId);
//	public List<Seat> getListOfSeats();
//	public Seat getSeatById(int seatId) throws BookingBlockedException;

}
